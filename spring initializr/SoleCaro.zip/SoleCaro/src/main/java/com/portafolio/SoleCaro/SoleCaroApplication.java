package com.portafolio.SoleCaro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoleCaroApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoleCaroApplication.class, args);
	}

}
